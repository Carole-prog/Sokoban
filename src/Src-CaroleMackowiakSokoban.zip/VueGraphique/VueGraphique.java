package VueGraphique;

public class VueGraphique {
    public static void main(String[] args) {
        new Menu();
    }
}
