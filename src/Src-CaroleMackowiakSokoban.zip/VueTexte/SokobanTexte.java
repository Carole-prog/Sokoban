package VueTexte;

import java.io.IOException;

public class SokobanTexte {
    /**
     * Point d'entrée pour lancer l'application
     * 
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        new MenuTexte();
    }
}
